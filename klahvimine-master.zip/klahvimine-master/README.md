# klahvimine 

* Mäng, mille eesmärk on võimalikult kiiresti ekraanile tekkivaid sõnu ära trükkida
* Sõnad võetud [Eesti Keele Instituudi lehelt](http://www.eki.ee/tarkvara/wordlist/), [lemmad2013](http://www.eki.ee/tarkvara/wordlist/lemmad2013.txt)